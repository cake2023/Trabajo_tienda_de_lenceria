-- Active: 1730726480803@@127.0.0.1@3306

drop table if exists categorias;
drop table if exists marcas;
drop table if exists productos;
drop table if exists clientes;

create table categorias(
    id_categoria integer,
    nombre_categoria varchar(25) not null,
    primary key (id_categoria)
);

create table marcas(
    id_marca integer,
    nombre_marca varchar(25) not null,
    primary key (id_marca)
);

create table productos(
    id integer,
    nombre varchar(25) not null,
    descripcion varchar(100) not null,
    precio decimal(10,2) not null,
    id_categoria int not null,
    id_marca int not null,
    FOREIGN key (id_categoria) REFERENCES categorias (id_categoria),
    FOREIGN key (id_marca) REFERENCES marcas (id_marca),
    primary key (id)
);

create table clientes(
    id integer,
    nombre varchar(25) not null,
    apellido varchar(25) not null,
    telefono varchar(20) not null,
    email varchar(50) not null,
    id_producto int not null,
    FOREIGN key (id_producto) REFERENCES productos (id),
    primary key (id)
);



