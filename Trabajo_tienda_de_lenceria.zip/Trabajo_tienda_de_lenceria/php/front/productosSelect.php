<?php
include_once "php/connectors/connector.php";
$connector=new Connector();
$registros=$connector->getAll("productos");
foreach ($registros as $registro) {
    echo "<option value='" . $registro['id'] . "'>" .
            $registro['id'].', '.$registro['nombre'].', '.$registro['descripcion']
            .', '.$registro['precio'].', '.$registro['id_categoria'].', '.$registro['id_categoria']
        ."</option><br>";
}
?>