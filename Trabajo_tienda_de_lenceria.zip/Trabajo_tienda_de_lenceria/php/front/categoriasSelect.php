<?php
include_once "php/connectors/connector.php";
$connector=new Connector();
$registros=$connector->getAll("categorias");
foreach ($registros as $registro) {
    echo "<option value='" . $registro['id_categoria'] . "'>" .
            $registro['id_categoria'].', '.$registro['nombre_categoria']
        ."</option><br>";
}
?>