<?php
include_once "php/connectors/connector.php";
$connector = new Connector();
$buscar="";
if(isset($_REQUEST['buscar'])) $buscar=$_REQUEST['buscar'];
$registros = $connector->get("marcas","id_marca like '%".$buscar."%'");
foreach ($registros as $registro) {
    echo ("<tr>");
    echo ("<td>" . $registro['id_marca'] . "</td>");
    echo ("<td>" . $registro['nombre_marca'] . "</td>");
    echo ("</tr>");
}
?>