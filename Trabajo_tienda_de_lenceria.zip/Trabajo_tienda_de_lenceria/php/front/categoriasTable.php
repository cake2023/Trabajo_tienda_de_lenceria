<?php
include_once "php/connectors/connector.php";
$connector = new Connector();
$buscar="";
if(isset($_REQUEST['buscar'])) $buscar=$_REQUEST['buscar'];
$registros = $connector->get("categorias","nombre_categoria like '%".$buscar."%'");
foreach ($registros as $registro) {
    echo ("<tr>");
    echo ("<td>" . $registro['id_categoria'] . "</td>");
    echo ("<td>" . $registro['nombre_categoria'] . "</td>");
    echo ("</tr>");
}
?>