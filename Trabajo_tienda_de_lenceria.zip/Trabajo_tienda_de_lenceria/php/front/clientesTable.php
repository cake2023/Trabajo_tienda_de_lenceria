<?php ini_set("display_errors", "1"); ?>
<?php
include_once "php/connectors/connector.php";
$connector = new Connector();
$buscar="";
if(isset($_REQUEST['buscar'])) $buscar=$_REQUEST['buscar'];
$registros = $connector->get("clientes","apellido like '%".$buscar."%'");
foreach ($registros as $registro) {
    echo ("<tr>");
    echo ("<td>" . $registro['id'] . "</td>");
    echo ("<td>" . $registro['nombre'] . "</td>");
    echo ("<td>" . $registro['apellido'] . "</td>");
    echo ("<td>" . $registro['telefono'] . "</td>");
    echo ("<td>" . $registro['telefono'] . "</td>");
    echo ("<td>" . $registro['id_producto'] . "</td>");
    echo ("</tr>");
}
?>
