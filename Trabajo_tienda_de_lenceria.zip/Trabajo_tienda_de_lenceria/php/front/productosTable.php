<?php
include_once "php/connectors/connector.php";
$connector = new Connector();
$buscar = "";
if (isset($_REQUEST['buscar'])) $buscar = $_REQUEST['buscar'];
$registros = $connector->get("productos", "descripcion like '%" . $buscar . "%'");
foreach ($registros as $registro) {
    echo ("<tr>");
    echo ("<td>" . $registro['id'] . "</td>");
    echo ("<td>" . $registro['nombre'] . "</td>");
    echo ("<td>" . $registro['descripcion'] . "</td>");
    echo ("<td>" . $registro['precio'] . "</td>");
    echo ("<td>" . $registro['id_categoria'] . "</td>");
    echo ("<td>" . $registro['id_marca'] . "</td>");
    echo ("</tr>");
}
