<?php
include_once "php/connectors/connector.php";
$connector=new Connector();
$registros=$connector->getAll("marcas");
foreach ($registros as $registro) {
    echo "<option value='" . $registro['id_marca'] . "'>" .
            $registro['id_marca'].', '.$registro['nombre_marca']
        ."</option><br>";
}
?>