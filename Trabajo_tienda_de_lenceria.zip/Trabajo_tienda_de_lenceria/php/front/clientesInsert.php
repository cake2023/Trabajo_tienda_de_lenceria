<?php ini_set("display_errors", "1"); ?>
<?php

include_once 'php/connectors/connector.php';
if (
    isset($_REQUEST['nombre']) && $_REQUEST['nombre'] != '' &&
    isset($_REQUEST['apellido']) && $_REQUEST['apellido'] != '' &&
    isset($_REQUEST['telefono']) && $_REQUEST['telefono'] != '' &&
    isset($_REQUEST['email']) && $_REQUEST['email'] != '' &&
    isset($_REQUEST['id_producto']) && $_REQUEST['id_producto'] != '' 
) {
    $nombre = $_REQUEST['nombre'];
    $apellido = $_REQUEST['apellido'];
    $telefono = $_REQUEST['telefono'];
    $email = $_REQUEST['email'];
    $id_producto = $_REQUEST['id_producto'];

    $tabla = "clientes";
    $campos = "nombre,apellido,telefono,email,id_producto";
    $values = "'" . $nombre . "','" . $apellido . "','" . $telefono. "','" . $email. "','" . $id_producto . "'";
    $connector=new Connector();
    $connector->insert($tabla,$campos,$values);
    echo 'Se ingreso un nuevo cliente!';
} else {
    echo 'Ingrese un nuevo cliente!';
}
?>
