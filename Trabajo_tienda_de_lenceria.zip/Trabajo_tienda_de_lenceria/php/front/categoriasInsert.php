<?php ini_set("display_errors", "1"); ?>
<?php
include_once 'php/connectors/connector.php';
if (
    isset($_REQUEST['id_categoria']) && $_REQUEST['id_categoria'] != '' &&
    isset($_REQUEST['nombre_categoria']) && $_REQUEST['nombre_categoria'] != '' 
) {
    $id_categoria = $_REQUEST['id_categoria'];
    $nombre_categoria = $_REQUEST['nombre_categoria'];

    $tabla = "categorias";
    $campos = "id_categoria,nombre_categoria";
    $values = "'" . $id_categoria . "','" . $nombre_categoria. "'";
    $connector=new Connector();
    $connector->insert($tabla,$campos,$values);
    echo 'Se ingreso una nueva categoria!';
} else {
    echo 'Ingrese una nueva categoria!';
}
?>