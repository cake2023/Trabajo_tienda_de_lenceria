<?php ini_set("display_errors", "1"); ?>
<?php
include_once 'php/connectors/connector.php';
if (
    isset($_REQUEST['nombre_marca']) && $_REQUEST['nombre_marca'] != '' 
) {
    $nombre_marca = $_REQUEST['nombre_marca'];

    $tabla = "marcas";
    $campos = "nombre_marca";
    $values = "'" . $nombre_marca. "'";
    $connector=new Connector();
    $connector->insert($tabla,$campos,$values);
    echo 'Se ingreso una nueva marca!';
} else {
    echo 'Ingrese una nueva marca!';
}
?>