<?php ini_set("display_errors", "1"); ?>
<?php
include_once 'php/connectors/connector.php';
if (
    isset($_REQUEST['nombre']) && $_REQUEST['nombre'] != '' &&
    isset($_REQUEST['descripcion']) && $_REQUEST['descripcion'] != '' &&
    isset($_REQUEST['precio']) && $_REQUEST['precio'] != '' &&
    isset($_REQUEST['id_categoria']) && $_REQUEST['id_categoria'] != '' &&
    isset($_REQUEST['id_marca']) && $_REQUEST['id_marca'] != ''
) {
    $nombre = $_REQUEST['nombre'];
    $descripcion = $_REQUEST['descripcion'];
    $precio = $_REQUEST['precio'];
    $id_categoria = $_REQUEST['id_categoria'];
    $id_marca = $_REQUEST['id_marca'];

    $tabla = "productos";
    $campos = "nombre, descripcion, precio, id_categoria, id_marca";
    $values = "'" . $nombre . "','" . $descripcion . "','" . $precio . "','" . $id_categoria . "','" . $id_marca . "'";
    $connector = new Connector();
    $connector->insert($tabla, $campos, $values);
    echo 'Se ingreso un nuevo producto!';
} else {
    echo 'Ingrese un nuevo producto!';
}
?>