<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tienda de lenceria</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body onload="mueveReloj()">
    <div class= "container-lg">

        <!-- Menú de navegación -->
        <?php include_once "menu.php"; ?>

        <!-- Banner -->
        <h1  style="font-style: italic;" class="bg-secondary-subtle  text-warning-emphasis text-center p-2">Mantenimiento de Productos</h1>

        <!-- Formulario de productos -->
        <form class="p-4  bg-secondary ">

            <!-- Nombre -->
            <div class="mb-3 row">
                <label for="nombre" class="col-sm-3 col-form-label  text-white" style="font-size: 22px;">Producto</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control  text-warning-emphasis" id="nombre"
                        name="nombre" value="">
                </div>
            </div>

            <!-- Descripción -->
            <div class="mb-3 row">
                <label for="descripcion" class="col-sm-3 col-form-label  text-white" style="font-size: 22px;">Descripción</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control  text-warning-emphasis" id="descripcion"
                        name="descripcion" value="">
                </div>
            </div>

            <!-- Precio -->
            <div class="mb-3 row">
                <label for="precio" class="col-sm-3 col-form-label  text-white" style="font-size: 22px;">Precio</label>
                <div class="col-sm-9">
                    <input type="number" class="form-control  text-warning-emphasis" id="precio"
                        name="precio" value="" step="0.0001">
                </div>
            </div>

            <!-- Id_categoria-->
            <div class="mb-3 row">
                <label for="id_categoria" class="col-sm-3 col-form-label  text-white" style="font-size: 22px;">Id_categoria</label>
                <div class="col-sm-9">
                    <select id="id_categoria" name="id_categoria" class="form-select  text-warning-emphasis" aria-label="Default select example">
                        <?php include_once "php/front/categoriasSelect.php"; ?>
                    </select>
                </div>
            </div>

            <!-- Id_marca-->
            <div class="mb-3 row">
                <label for="id_marca" class="col-sm-3 col-form-label  text-white" style="font-size: 22px;">Id_marca</label>
                <div class="col-sm-9">
                    <select id="id_marca" name="id_marca" class="form-select  text-warning-emphasis" aria-label="Default select example">
                        <?php include_once "php/front/marcasSelect.php"; ?>
                    </select>
                </div>
            </div>

            <!-- Botones-->
            <div class="mb-3 row">
                <button type="submit" class="btn btn-outline-light col-sm-3 m-2">Guardar</button>
                <button type="reset" class="btn btn-outline-info col-sm-3 m-2">Borrar</button>
            </div>

            <!-- Información -->
            <div class="mb-3 row">
                <label for="info" class="col-sm-3 col-form-label  text-white" style="font-size: 22px;">Información</label>
                <div class="col-sm-9">
                    <div class="form-control  text-warning-emphasis" id="info">
                        <?php include_once "php/front/productosInsert.php";
                        ?>
                    </div>
                </div>
            </div>
        </form>

        <!-- Tabla de Productos -->
        <table class="table table-success table-striped table-hover">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Producto</th>
                    <th scope="col">Descripción</th>
                    <th scope="col">Precio</th>
                    <th scope="col">Id_categoria</th>
                    <th scope="col">Id_marca</th>
                    <th scope="col"></th>
                </tr>
            </thead>
            <tbody>
                <?php include_once "php/front/productosTable.php";
                ?>
            </tbody>
        </table>

    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="js/reloj.js"></script>
    <script src="js/main.js"></script>
</body>

</html>